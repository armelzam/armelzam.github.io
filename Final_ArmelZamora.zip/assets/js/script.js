function Alert() {
    alert("Trust the process, we will begin shipping the drip soon.");
}
